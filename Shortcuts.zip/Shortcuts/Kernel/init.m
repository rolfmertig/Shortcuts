(* Wolfram Language Init File *)

Get[ "Shortcuts`Shortcuts`"]